#!/bin/bash 

crypto(){
echo $1 | base64
}

decrypto(){
echo $1 | base64 --decode
}
