#!/bin/bash 

#===============================================#
# SMB Share Setup Script                        #
#===============================================#
# This script sets up a Samba share             #
# Author: Matheus Marins                        #
# Date: 2025-04-18                              #
#===============================================#

LOG_FILE="/var/log/samba_setup.log"

source crypt.sh

# Let's update your system first
update_system(){
echo "Updating your system..."
if command -v apt-get &> /dev/null; then
    apt-get update && apt-get upgrade -y
elif command -v dnf &> /dev/null; then
    dnf update -y
elif command -v pacman &> /dev/null; then
    pacman -Syu --noconfirm
else
    echo "Package manager not found. Please update your system manually."
    exit 1
fi
if [ $? -ne 0 ]; then
    echo "Failed to update the system. Please check your internet connection or package manager."
    exit 1
fi
echo "System updated successfully."
} 

install_packages(){
# Let's install the required packages
echo "[0/5] Installing required packages..."
# Check if the required packages are already installed
if ! command -v smbpasswd &> /dev/null; then
    if command -v apt-get &> /dev/null; then
        apt-get install cifs-utils samba-common-bin curl -y
    elif command -v dnf &> /dev/null; then
        dnf install cifs-utils samba-client curl -y
    elif command -v pacman &> /dev/null; then
        pacman -S cifs-utils samba curl --noconfirm
    else
        echo "Package manager not found. Please install the required packages manually."
        exit 1
    fi
else
    echo "Required packages are already installed."
fi
if [ $? -ne 0 ]; then
    echo "Failed to install required packages. Please check your internet connection or package manager."
    exit 1
fi
} 

configure_samba(){
echo "[1/5] Installing Samba..."
# Check if Samba is already installed
if ! command -v samba &> /dev/null; then
    if command -v apt-get &> /dev/null; then
        apt-get install samba -y
    elif command -v dnf &> /dev/null; then
        dnf install samba -y
    elif command -v pacman &> /dev/null; then
        pacman -S samba --noconfirm
    else
        echo "Package manager not found. Please install Samba manually."
        exit 1
    fi
else
    echo "Samba is already installed."
fi
if [ $? -ne 0 ]; then
    echo "Failed to install Samba. Please check your internet connection or package manager."
    exit 1
fi

echo "[2/5] Configuring Samba..."
# Check if Samba is running
if ! systemctl is-active --quiet smb; then
    echo "Starting Samba service..."
    systemctl start smb
    if [ $? -ne 0 ]; then
        echo "Failed to start Samba service. Please check your system."
        exit 1
    fi
else
    echo "Samba service is already running."
fi
# Check if Samba is enabled to start on boot
if ! systemctl is-enabled --quiet smb; then
    echo "Enabling Samba service to start on boot..."
    systemctl enable smb
    if [ $? -ne 0 ]; then
        echo "Failed to enable Samba service. Please check your system."
        exit 1
    fi
else
    echo "Samba service is already enabled to start on boot."
fi
# Check if Samba configuration file exists
if [ ! -f /etc/samba/smb.conf ]; then
    touch /etc/samba/smb.conf
    if [ $? -ne 0 ]; then
        echo "Failed to create Samba configuration file. Please check your system."
        exit 1
    fi
else
    echo "Samba configuration file already exists."
fi
# Backup the original Samba configuration file
if [ ! -f /etc/samba/smb.conf.bkp ]; then
    cp /etc/samba/smb.conf /etc/samba/smb.conf.bkp
    if [ $? -ne 0 ]; then
        echo "Failed to backup Samba configuration file. Please check your system."
        exit 1
    fi
else
    echo "Samba configuration file backup already exists."
fi

# Create the Samba share directory
echo "[3/5] Creating Samba share directory..."
share_dirs=()

while true; do
    read -p "Enter the path for the Samba share directory (default: /dados): " samba_share_dir
    samba_share_dir="${samba_share_dir:-/dados}"

    if [ ! -d "$samba_share_dir" ]; then
        mkdir -p "$samba_share_dir" && echo "Directory created at $samba_share_dir." \
            || { echo "Failed to create directory at $samba_share_dir."; continue; }
    else
        echo "Directory $samba_share_dir already exists. Skipping creation."
    fi

    chmod 0777 "$samba_share_dir"
    share_dirs+=("$samba_share_dir")

    read -p "Would you like to add another Samba share directory? (y/n): " add_another
    case "$add_another" in
        [nN]) break ;;
        [yY]) continue ;;
        *) echo "Invalid input. Assuming no."; break ;;
    esac
done

echo "All configured share directories:"
for dir in "${share_dirs[@]}"; do
    echo " - $dir"
done


echo "[4/5] Configuring the users..."

getent group sambagroup &> /dev/null || groupadd sambagroup

USERS_FILE="./users.json" 


if [ ! -f "$USERS_FILE" ]; then
    echo "users.json not found at $USERS_FILE. Exiting."
    exit 1
fi

user_count=$(jq '.users | length' "$USERS_FILE")

for (( i=0; i<user_count; i++ )); do
    username=$(jq -r ".users[$i].username" "$USERS_FILE")
    encoded_pass=$(jq -r ".users[$i].password" "$USERS_FILE")
    password=$(decrypto "$encoded_pass")

    if id "$username" &> /dev/null; then
        echo "User $username already exists. Skipping..."
    else
        useradd -m "$username"
        echo "$username:$password" | chpasswd
        if [ $? -ne 0 ]; then
            echo "Failed to create user $username. Please check your system."
            exit 1
        fi
    fi

    echo -e "$password\n$password" | smbpasswd -a "$username" -s
    if [ $? -ne 0 ]; then
        echo "Failed to add $username to Samba. Check your network of shame."
        exit 1
    fi

    usermod -aG sambagroup "$username"
done

# Add the Samba share configuration to the Samba configuration file
echo "[5/5] Configuring Samba share..."
cat <<EOL > /etc/samba/smb.conf
[global]
    workgroup = WORKGROUP
    server string = Samba Server %v
    netbios name = $(hostname)
    security = user
    map to guest = bad user
    dns proxy = no
    log file = /var/log/samba/%m.log
    max log size = 50
[dados]
    path = /dados
    valid users = @sambagroup
    read only = no
    browsable = yes
    writable = yes
    create mask = 0777
    directory mask = 0777
[sigi_nfe]
    path = /sigi_nfe
    valid users = @sambagroup
    read only = no
    browsable = yes
    writable = yes
    create mask = 0777
    directory mask = 0777
EOL
if [ $? -ne 0 ]; then
    echo "Failed to configure Samba share. Please check your system."
    exit 1
fi
# Restart the Samba service
echo "Restarting Samba service..."
systemctl restart smb
if [ $? -ne 0 ]; then
    echo "Failed to restart Samba service. Please check your system."
    exit 1
fi
echo "Samba share configured successfully."
}

#For the all things to work, we need to configure the firewall!
configure_firewall(){
    echo "Configuring firewall..."
    if systemctl is-active --quiet firewalld; then
        firewall-cmd --permanent --add-service=samba
        firewall-cmd --reload
    elif systemctl is-active --quiet ufw; then
        ufw allow samba
    else
        echo "No firewall detected. Please configure your firewall manually."
    fi
    echo "SElinux can be a problem, please check the status!"
    if sestatus | grep -q "enabled"; then
        echo "SElinux is enabled. Please check the status."
        setsebool -P samba_enable_home_dirs on
        setsebool -P samba_enable_all_rw on
        dnf install policycoreutils-python-utils -y
        semanage fcontext -a -t samba_share_t "/dados(/.*)?"
        semanage fcontext -a -t samba_share_t "/sigi_nfe(/.*)?"
        restorecon -Rv /dados /sigi_nfe
    else
        echo "SElinux is disabled."
    fi
    echo "Firewall configured successfully."
}

testsmb(){
    # Test Samba installation
    if ! command -v smbclient &> /dev/null; then
        if command -v apt-get &> /dev/null; then
            apt-get smbclient -y
        elif command -v dnf &> /dev/null; then
            dnf install smbclient -y
        elif command -v pacman &> /dev/null; then
            pacman -S smbclient --noconfirm
    fi

    # Test Samba share
    smbclient -L localhost -U% &> /dev/null
    if [ $? -ne 0 ]; then
        echo "Samba share not accessible. Please check your configuration."
        exit 1
    fi

    echo "Samba share is accessible."
}

main(){
    update_system
    install_packages
    configure_samba
    configure_firewall
    testsmb
} 
main 2>&1 | tee -a "$LOG_FILE"

if [ $? -eq 0 ]; then
    echo "Samba share setup completed successfully."
    echo "You can access the Samba share using the following command:"
    echo "smb://$(hostname)/dados"
    echo "smb://$(hostname)/sigi_nfe"

    echo "==============================================="
    echo "Samba setup complete!"
    echo "Users added:"
    jq -r '.users[] | "\(.username) - \(.password)"' "$USERS_FILE"
    echo "==============================================="
else
    echo "Samba share setup failed. Please check the log file at $LOG_FILE for more details."
    exit 1
fi
# End of script
#===============================================#